import { Component, Input, OnChanges, EventEmitter, Output,  SimpleChanges, OnInit, OnDestroy, AfterViewInit, AfterViewChecked } from '@angular/core';


@Component({
  selector: 'app-child1',
  templateUrl: './child1.component.html',
  styleUrls: ['./child1.component.css'],
})
export class Child1Component implements OnChanges, OnInit, OnDestroy, AfterViewInit, AfterViewChecked {
  @Input() counts: number;
 @Input () users:any;
 @Output() sentData: EventEmitter<any> = new EventEmitter<any> ();
mes= 'hi jegan';


  ngOnChanges(change: SimpleChanges){
    console.log('oncjanges')
    for(let property in change){
      if(property === 'counts'){
        if(change[property].currentValue==5)
        alert (this.mes)
      }
    }
  }

sentParent(){
  this.sentData.emit ('Test child to parent');
}
ngOnInit(){
  console.log("componet init")
}
ngAfterViewChecked(){
  console.log("child data changed")
}

ngAfterViewInit(){
console.log("child view init")
}

ngOnDestroy(){
  console.log("componet destroy")
}
}
