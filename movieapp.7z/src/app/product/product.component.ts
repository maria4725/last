import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.css'],
})
export class ProductComponent implements OnInit, DoCheck {
  count: number = 0;
  yi = 'jega';
  constructor() {}

  ngOnInit(): void {}
  ngDoCheck() {
    console.log('ng do check');
  }
  increase() {
    this.count++;
    if (this.count == 10) {
      alert('limit exceeed');
    }
  }
  decrease() {
    this.count--;
  }

  receiveData(event) {
    document.getElementById('out').innerHTML = event;
  }
}
