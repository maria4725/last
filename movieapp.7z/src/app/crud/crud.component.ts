import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { TodoService } from '../todo.service';
import {MatSort} from '@angular/material/sort';

@Component({
  selector: 'app-crud',
  templateUrl: './crud.component.html',
  styleUrls: ['./crud.component.css'],
})
export class CrudComponent implements OnInit, AfterViewInit {
  todo = null;
  apiTodo:any=[];
  @ViewChild(MatSort) sort: MatSort;


  constructor(private crud: TodoService) {
   
  }
  displayedColumns: string[] = ['id', 'title'];

  ngOnInit(): void {
    this.crud.getTodoData().subscribe((ok:any)=>
     {this.apiTodo=ok}
     )
  }
  ngAfterViewInit() {
    
    this.apiTodo.sort = this.sort;
  }
  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.apiTodo.filter = filterValue.trim().toLowerCase();
  }

}
