import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { MatButtonModule } from '@angular/material/button';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatBadgeModule } from '@angular/material/badge';
import { MatRippleModule } from '@angular/material/core';
import { MatListModule } from '@angular/material/list';
import { MatCardModule } from '@angular/material/card';
import { MatDialogModule } from '@angular/material/dialog';
import { SharedModule } from './shared/shared.module';
import {MatTableModule} from '@angular/material/table';
import { ChartsModule } from 'ng2-charts';
import {MatGridListModule} from '@angular/material/grid-list';


// Components
import { AppComponent } from './app.component';
import { ProductComponent } from './product/product.component';
import { SearchFilterPipe, testPipe} from './search-filter.pipe';
import { Child1Component } from './child1/child1.component';
import {
  Dynamic1Component,
  Dynamic2Component,
} from './child2/child2.component';
import { LeftbarComponent } from './leftbar/leftbar.component';
import { HeaderComponent } from './header/header.component';
import { ContainerComponent } from './container/container.component';
import { PipetestComponent } from './pipetest/pipetest.component';
import { DirComponent } from './dir/dir.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { StructuralComponent } from './structural/structural.component';
import { CustomdirDirective } from './customdir.directive';
import { UserlistService } from './userlist.service';
import { ServicesComponent } from './services/services.component';
import { ApidataComponent } from './apidata/apidata.component';
import { FormsComponent } from './forms/forms.component';
import { DynamicComponentComponent } from './dynamic-component/dynamic-component.component';
import { HostDirective } from './host.directive';
import { Comp3Component } from './comp3/comp3.component';
import { Comp4Component } from './comp4/comp4.component';
import { DynmicDirective } from './dynmic.directive';
import { RxjscompComponent } from './rxjscomp/rxjscomp.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { ObservableComponent } from './observable/observable.component';
import { CrudComponent } from './crud/crud.component';
import { InterceptorComponent } from './interceptor/interceptor.component';
import { HttpInterceptorInterceptor } from './http-interceptor.interceptor';
import { RoutingComponent } from './routing/routing.component';
import { UsersComponent } from './users/users.component';
import {HostbindsComponent} from './hostbinds/hostbinds.component';
import { ChartComponent } from './chart/chart.component'
@NgModule({
  declarations: [
    AppComponent,
    ProductComponent,
    SearchFilterPipe,
    Child1Component,
    Dynamic1Component,
    Dynamic2Component,
    LeftbarComponent,
    HeaderComponent,
    ContainerComponent,
    HostbindsComponent,
    PipetestComponent,
    DirComponent,
    DatabindingComponent,
    StructuralComponent,
    CustomdirDirective,
    ServicesComponent,
    ApidataComponent,
    FormsComponent,
    DynamicComponentComponent,
    HostDirective,
    Comp3Component,
    Comp4Component,
    DynmicDirective,
    RxjscompComponent,
    LifecycleComponent,
    ObservableComponent,
    CrudComponent,
    testPipe,
    InterceptorComponent,
    RoutingComponent,
    UsersComponent,
    ChartComponent,
    
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule,
    BrowserAnimationsModule,
    MatButtonModule,
    MatToolbarModule,
    MatIconModule,
    MatSidenavModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatBadgeModule,
    MatRippleModule,
    MatListModule,
    MatCardModule,
    MatDialogModule,
    MatTableModule,
    ChartsModule,
    MatGridListModule
  ],
  entryComponents: [
    Dynamic1Component,
    Dynamic2Component,
    Comp3Component,
    Comp4Component,
  ],
  providers: [UserlistService,{provide: HTTP_INTERCEPTORS, useClass:HttpInterceptorInterceptor,multi:true}],
  bootstrap: [AppComponent],
  
})
export class AppModule {}
