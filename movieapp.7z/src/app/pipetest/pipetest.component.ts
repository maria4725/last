import { Component, OnInit } from '@angular/core';
import { HttpClient} from '@angular/common/http';
import {map, take } from 'rxjs/operators';
import {  interval } from 'rxjs';


@Component({
  selector: 'app-pipetest',
  templateUrl: './pipetest.component.html',
  styleUrls: ['./pipetest.component.css']
})
export class PipetestComponent implements OnInit {
  dates = new Date();
  rs= 19497.600;
  num= 366738;
  slice= [3,6,5,3,6,7,3,8];
  str= "hi jegan";
  str2 = "DEI PRAKASH";
  constructor(private http: HttpClient) { }

  jsonData = this.http.get("todos/1");
  ngOnInit(): void {
  }

  date$= interval(1000).pipe(
    map(x => new Date()),
    take(10)
  )


}
