import { NgModule } from '@angular/core';
import { UserlistService } from '../userlist.service';

@NgModule({
  providers: [UserlistService],
})
export class SharedModule {}
