import { Component, HostBinding, OnInit } from '@angular/core';

@Component({
  selector: 'app-hostbinds',
  templateUrl: './hostbinds.component.html',
  styleUrls: ['./hostbinds.component.css']
})
export class HostbindsComponent implements OnInit {

  // @HostBinding ('class') add = 'list';
  @HostBinding ('style.color') add = 'red';
  constructor() { }

  ngOnInit(): void {
  }

  change(){
    this.add = "green";
  }
}
