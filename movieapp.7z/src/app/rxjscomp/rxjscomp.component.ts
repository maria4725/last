import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rxjscomp',
  templateUrl: './rxjscomp.component.html',
  styleUrls: ['./rxjscomp.component.css']
})
export class RxjscompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
