import { Component, OnInit } from '@angular/core';
import { UserlistService } from '../userlist.service';

@Component({
  selector: 'app-services',
  templateUrl: './services.component.html',
  styleUrls: ['./services.component.css']
})
export class ServicesComponent implements OnInit {
  usersdata= [];

  constructor(private myserv:UserlistService) { }

  ngOnInit() {
    this.usersdata = this.myserv.usersdata;
  
  }
    
}
