import {
  Component,
  OnInit,
  ViewChild,
  ComponentFactoryResolver,
} from '@angular/core';
import {
  Dynamic1Component,
  Dynamic2Component,
} from '../child2/child2.component';
import { Comp3Component } from '../comp3/comp3.component';
import { Comp4Component } from '../comp4/comp4.component';

import { DynmicDirective } from '../dynmic.directive';
import { HostDirective } from '../host.directive';

@Component({
  selector: 'app-dynamic-component',
  templateUrl: './dynamic-component.component.html',
  styleUrls: ['./dynamic-component.component.css'],
})
export class DynamicComponentComponent implements OnInit {
  @ViewChild(HostDirective, { static: true })
  childRef: HostDirective;

  ///pure componet child
  @ViewChild(DynmicDirective, { static: true })
  child: DynmicDirective;

  comp = [Comp3Component, Comp4Component];
  components = [Dynamic1Component, Dynamic2Component];

  
  constructor(public FactoryRes: ComponentFactoryResolver) {}

  loadcomponent(id) {
    this.childRef.viewref.clear();
    const resolvedfactory = this.FactoryRes.resolveComponentFactory(
      this.components[id]
    );
    this.childRef.viewref.createComponent(resolvedfactory);
  }

  loadcomp(id) {
    this.child.viewRef.clear();
    const resolver = this.FactoryRes.resolveComponentFactory(this.comp[id]);
    this.child.viewRef.createComponent(resolver);
  }
  ngOnInit() {
    this.getAds();
  }
  interval: any;
  getAds() {
    this.interval = setInterval(() => {
      this.loadcomponent(1);
    }, 3000);
  }
}
