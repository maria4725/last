import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leftbar',
  templateUrl: './leftbar.component.html',
  styleUrls: ['./leftbar.component.css']
})
export class LeftbarComponent implements OnInit {
  toggleShow:boolean = true;
  constructor() { }

  ngOnInit(): void {
  }


  openNav() {
    document.getElementById("mySidenav").style.width = "250px";
    document.getElementById("main").style.marginLeft = "250px";
  }
  
  closeNav() {
    document.getElementById("mySidenav").style.width = "90px";
    document.getElementById("main").style.marginLeft= "90px";
  }
  
  
  togg(){
 this.toggleShow=!this.toggleShow;
 
  }
}
