import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dir',
  templateUrl: './dir.component.html',
  styleUrls: ['./dir.component.css']
})
export class DirComponent implements OnInit {
  show = true;
  constructor() { }

  ngOnInit(): void {
  }
  nam() {
    this.show = !this.show;
  }
}
