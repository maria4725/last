import { Directive, ElementRef, HostListener, Input } from '@angular/core';

@Directive({
  selector: '[appCustomdir]'
})
export class CustomdirDirective {
  @Input() highLightColor;
  constructor(public eleRef:ElementRef) { 
    // jd.nativeElement.style.color="red";
    eleRef.nativeElement.style.color="green";

  }
  @HostListener('mouseenter') mouseEnter(){
    this.eleRef.nativeElement.style.color = 'red';
  }
  @HostListener('mouseleave') mouseLeave(){
    this.eleRef.nativeElement.style.color = 'blue';
  }

}
