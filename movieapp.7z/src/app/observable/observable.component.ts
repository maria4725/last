import { Component, OnInit } from '@angular/core';
import { from, Observable, Subscriber } from 'rxjs';
import{ observable} from 'rxjs';
@Component({
  selector: 'app-observable',
  templateUrl: './observable.component.html',
  styleUrls: ['./observable.component.css']
})
export class ObservableComponent implements OnInit {

  constructor() {
    const test$ = new Observable(subscriber => {
      console.log('text 1');
      subscriber.next('1');
    });
    test$.subscribe(x => {
      console.log(x);
    })
   }

  ngOnInit(): void {
  }

}
