import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'searchFilter'
})
export class SearchFilterPipe implements PipeTransform {

transform(value, searchText){
  let filteredList=[];
if(searchText) {
  let newSearchTerm=!isNaN(searchText)? searchText.toString(): searchText.toString().toUpperCase();
let prop;
return value.filter(item =>{
  for(let key in item){
    prop=isNaN(item[key]) ? item[key].toString().toUpperCase() : item[key].toString();
  
    if(prop.indexOf(newSearchTerm) > -1){
        filteredList.push(item);
        return filteredList;}
    }
})
}
else{
    return value;
    }
}
}

@Pipe({
  name: 'testPipes'
})
export class testPipe implements PipeTransform{

  transform(value){
  return value + " Ok";
  }
}
    