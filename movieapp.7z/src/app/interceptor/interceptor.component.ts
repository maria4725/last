import { Component, OnInit } from '@angular/core';
import {UserlistService} from '../userlist.service'
@Component({
  selector: 'app-interceptor',
  templateUrl: './interceptor.component.html',
  styleUrls: ['./interceptor.component.css']
})
export class InterceptorComponent implements OnInit {
alluser= null;
  constructor(private getuser: UserlistService) { 
    this.getuser.getAllUsers().subscribe((res)=>
    this.alluser=res);
  }

  ngOnInit(): void {
  }

}
