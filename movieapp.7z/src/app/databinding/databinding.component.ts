import { Component, OnInit } from '@angular/core';
import { from } from 'rxjs';

@Component({
  selector: 'app-databinding',
  templateUrl: './databinding.component.html',
  styleUrls: ['./databinding.component.css'],
})
export class DatabindingComponent implements OnInit {
  pname = 'Angular proberty binding in InnerHTML';

  iname = 'this is on ineterpolation binding most of use this binding';
  username;
  env = true;
  msg;
  constructor() {}

  ngOnInit(): void {}
  event() {
    this.env = !this.env;
  }

  myEvent(x: any) {
    console.log(x);
    this.msg = x.target.value;
  }
}
