import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { ProductComponent } from './product/product.component';
import { ContainerComponent } from './container/container.component';
import { PipetestComponent } from './pipetest/pipetest.component';

import { DirComponent } from './dir/dir.component';
import { DatabindingComponent } from './databinding/databinding.component';
import { StructuralComponent } from './structural/structural.component';
import { ServicesComponent } from './services/services.component';
import { FormsComponent } from './forms/forms.component';
import { DynamicComponentComponent } from './dynamic-component/dynamic-component.component';
import { HostbindsComponent } from './hostbinds/hostbinds.component';
import { RxjscompComponent } from './rxjscomp/rxjscomp.component';
import { LifecycleComponent } from './lifecycle/lifecycle.component';
import { ObservableComponent } from './observable/observable.component';
import { CrudComponent } from './crud/crud.component';
import { InterceptorComponent } from './interceptor/interceptor.component';
import { RoutingComponent } from './routing/routing.component';
import { UsersComponent } from './users/users.component';

const routes: Routes = [
  { path: 'container', redirectTo: '', pathMatch: 'full' },
  { path: 'product', component: ProductComponent },
  { path: '', component: ContainerComponent },
  { path: 'pipetest', component: PipetestComponent },
  { path: 'directives', component: DirComponent },

  { path: 'data_binding', component: DatabindingComponent },
  { path: 'structural', component: StructuralComponent },
  { path: 'services', component: ServicesComponent },
  { path: 'form', component: FormsComponent },
  { path: 'dynamic', component: DynamicComponentComponent },
  { path: 'host_binding', component: HostbindsComponent },
  { path: 'rxjs', component: RxjscompComponent },
  { path: 'lifecycle', component: LifecycleComponent },
  { path: 'observable', component: ObservableComponent },
  { path: 'crud', component: CrudComponent },
  { path: 'interceptor', component: InterceptorComponent },
  { path: 'routing', component: RoutingComponent },
  { path: 'users/add', component: UsersComponent,},
  { path: 'users/:id', component: UsersComponent,},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule],
  
})


export class AppRoutingModule {}
