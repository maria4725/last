import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-structural',
  templateUrl: './structural.component.html',
  styleUrls: ['./structural.component.css'],
})
export class StructuralComponent implements OnInit {
  movie = [
    { name: 'Master', acter: 'vijay', rating: '5/10' },
    { name: 'Tenet', acter: 'Robert Pattinson', rating: '7/10' },
    { name: 'Avengers', acter: 'Robert Downey', rating: '8/10' },
  ];
  ngif = 'sda';

  users= [{
    name: "jegan", g: "m"
  }, {
    name: "prakas", g: "f"
  }, {
    name: "asd", g: "f"
  }, {name: "jeasgan", g: "m"
}]
  switchUser: number;
  constructor() {}

  ngOnInit(): void {}
}
