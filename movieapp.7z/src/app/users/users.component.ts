import { Component, OnInit } from '@angular/core';
import { UserlistService, User} from '../userlist.service';
import { ActivatedRoute, Router } from "@angular/router";


@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {

  user: User = { id: 0, name: "", address: "" };
  constructor(
    public appService: UserlistService,
    private router: Router,
    private route: ActivatedRoute
  ) 
  {
    console.log("route", this.route);
    this.route.paramMap.subscribe(params => {
      const id = Number(params.get("id"));
      this.user = this.appService.getUser(id);
    });
  }

  onCancel() {
    this.router.navigateByUrl("/routing");
  }

  onSave() {
    if (this.user.id > 0) {
      this.appService.updateUser(this.user);
    } else {
      this.appService.addUser(this.user);
    }
    this.router.navigateByUrl("/routing");
  }

  onDelete() {
    this.appService.deleteUser(this.user.id);
    this.router.navigateByUrl("/routing");
  }
  ngOnInit(): void {
  }

}
