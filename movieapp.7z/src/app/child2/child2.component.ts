import { Component } from '@angular/core';

@Component({
  selector: 'dynamic1',
  template: `<div class="list">hi dymic Component - 1 <br /> - {{name}}</div>`,
  styleUrls: ['./child2.component.css'],
})
export class Dynamic1Component {
  name = 'jegan';
}

@Component({
  selector: 'dynamic2',
  template: `<div class="list">
    hi dymic Component - 2 <br />
    - {{ name }}
  </div>`,
  styleUrls: ['./child2.component.css'],
})
export class Dynamic2Component {
  name = 'praskash';
}
