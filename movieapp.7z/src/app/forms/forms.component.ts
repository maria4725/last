import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators } from '@angular/forms';
@Component({
  selector: 'app-forms',
  templateUrl: './forms.component.html',
  styleUrls: ['./forms.component.css']
})
export class FormsComponent  {

  
  ngForm = new FormGroup(
    {
      name : new FormControl('', [Validators.required, Validators.minLength(5)]),
      email : new FormControl('', [Validators.required, Validators.email]),
      password : new FormControl()
    }
  )
 
 
  FormData(){
    console.log(this.ngForm.value);
    document.getElementById("react").innerHTML=this.ngForm.value.name;
    document.getElementById("react").innerHTML=this.ngForm.value.email;
     }
  

     //template form function
  getFormData(data:any){
    console.log(data);
    console.log(data.name);
    console.log(data.email);
    document.getElementById("data").innerHTML=data.name + "<br>"+ data.email;

  }


  

}
