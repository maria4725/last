import { Directive, ViewContainerRef } from '@angular/core';

@Directive({
  selector: '[appDynmic]'
})
export class DynmicDirective {

  constructor(public viewRef: ViewContainerRef) { }

}
