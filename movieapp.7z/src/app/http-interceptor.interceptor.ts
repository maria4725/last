import { Injectable } from '@angular/core';
import {
  HttpRequest,
  HttpHandler,
  HttpEvent,
  HttpInterceptor,
} from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';

@Injectable()
export class HttpInterceptorInterceptor implements HttpInterceptor {
  constructor() {}

  intercept(
    request: HttpRequest<unknown>,
    next: HttpHandler
  ): Observable<HttpEvent<unknown>> {
    console.log('dsjs', request);
    const newReq = request.clone({
      url: 'https://jsonplaceholder.typicode.com/' + request.url,
      headers: request.headers.set('Autherization', 'jegan'),
    });
    return next.handle(newReq).pipe(
      tap(
        (result) => {
          console.log('sucess', result);
        },
        (error) => {
          console.log('sucess', error);
        }
      )
    );
  }
}
