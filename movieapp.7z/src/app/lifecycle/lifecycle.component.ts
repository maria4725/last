import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lifecycle',
  templateUrl: './lifecycle.component.html',
  styleUrls: ['./lifecycle.component.css']
})
export class LifecycleComponent implements OnInit {
show = false;
count= 0;
  constructor() { }
  shows(){
    this.show = !this.show
  }
  ngOnInit(): void {
    console.log("component")
  }

  increase(){
    this.count++;
  }

}
